const Header = () => {
  return <header>HEADER</header>
}

export default Header
