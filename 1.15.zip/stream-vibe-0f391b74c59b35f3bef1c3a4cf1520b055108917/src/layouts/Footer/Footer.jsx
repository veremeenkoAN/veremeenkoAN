const Footer = () => {
  return <footer>FOOTER</footer>
}

export default Footer
