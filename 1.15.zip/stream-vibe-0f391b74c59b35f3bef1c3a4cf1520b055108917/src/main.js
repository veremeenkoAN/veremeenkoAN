console.log('Привет!')
