export const metadata = {
  title: 'Movies & Shows',
}

export default function () {
  return (
    <>
      <h1>Фильмы</h1>
    </>
  )
}
