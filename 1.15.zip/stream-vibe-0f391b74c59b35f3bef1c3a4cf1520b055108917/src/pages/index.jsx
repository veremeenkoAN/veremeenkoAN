export const metadata = {
  title: 'Home',
}

export default function () {
  return (
    <>
      <h1>Главная</h1>
    </>
  )
}
